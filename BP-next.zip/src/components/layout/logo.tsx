import Image from "next/image";

export default function Logo() {
  return (
    <Image
      src="/logo.svg"
      width={30}
      height={30}
      className="transition-all group-data-collapsible:size-6 group-data-[collapsible=icon]:size-8"
      alt="Balance Pay logo"
    />
  );
}
